package com.hcl.bank.exception;

public class InsufficientFundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
